package cloud.nativ.javaee;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * The REST API application.
 */
@ApplicationPath("/api/")
public class SpellingAPI extends Application {
}
